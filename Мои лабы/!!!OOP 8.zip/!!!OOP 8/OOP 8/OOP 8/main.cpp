#include "Header.h"

void main()
{
	dialog D;
	D.execute();
	cout << endl;
	system("pause");
}